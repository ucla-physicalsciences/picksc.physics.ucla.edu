void sse_fallocate(float **s_f, int nsize, int *irc);

void sse_deallocate(void *s_d);

void ssadd(float g_a[], float g_b[], float g_c[], int nx);
