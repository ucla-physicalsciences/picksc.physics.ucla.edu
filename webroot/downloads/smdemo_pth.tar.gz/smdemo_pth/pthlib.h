void init_pt();

void setnthsize(int nth);

void copy_memptr(float *f, float *p_f, int nsize);

void ptadd(float *a, float *b, float *c, int nx, int *irc);

void end_pt();
