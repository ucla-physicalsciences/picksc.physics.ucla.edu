void mpadd(float a[], float b[], float c[], int nx);

void init_omp(int nth);

void setnthsize(int nth);
