/* C GPU Tutorial: Transpose         */
/* written by Viktor K. Decyk, UCLA  */

void transpose0(float a[], float b[], int nx, int ny);

void  transpose2(float a[], float b[], int mx, int my, int nx, int ny);
