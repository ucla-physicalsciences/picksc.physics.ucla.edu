/* C GPU Tutorial: Reduction        */
/* written by Viktor K. Decyk, UCLA  */

void sum0(float a[], float *s, int nx);

void sum1(float a[], float d[], int mx, int nx);

void sum2(float d[], float *s, int mx, int nxs);
