#define gray1_width 2
#define gray1_height 2
static char gray1_bits[] = {
   0x01, 0x02};
