// Database benchmark program
// Robert Henderson and Benjamin Zorn
// A Comparison of Object-oriented Programming in Four Modern Languages
// Software - Practice and Experience, vol. 24, no. 11, p. 1077 (1994).
// Simplified by Charles Norton and Viktor Decyk

// ***********************
// ****  personnel.h  ****
// ***********************

// #include <stream.h>
#include <iostream>
using namespace std;

class Personnel {
  static int NUM_FILES;
  char *firstname, *lastname;
 protected:
  int ssn;
 public:
  Personnel(const int s, const char *fn, const char *ln);
  ~Personnel();
  virtual void print(const int printssn = 0);
  virtual int getssn();
  static int get_num_files();
};


//*****************************
//****   personnel.cc   *******
//*****************************

#include <string.h>

// Initialize static class member
// Number of database records
int Personnel::NUM_FILES = 0;

// Constructor
Personnel::Personnel(const int s, const char *fn, const char *ln)
{
  ssn = s;
  firstname = new char[strlen(fn)+1];
  lastname  = new char[strlen(ln)+1];
  strcpy(firstname, fn);
  strcpy(lastname, ln);
  NUM_FILES++;
} 

// Destructor
Personnel::~Personnel()
{
  delete firstname;
  delete lastname;
  NUM_FILES--;
}

void Personnel::print(const int printssn)
{
  if (printssn)
      cout << ssn << ": " << firstname << ' ' << lastname << endl;
  else
      cout << firstname << ' ' << lastname << endl;
}

int Personnel::getssn() { return ssn; }

int Personnel::get_num_files() { return NUM_FILES; }


// ***********************
// ****   student.h   ****
// ***********************

class Student : public Personnel {
  int nclasses;
  char *classes[10];
public:
  Student(const int ssn, const char *firstname, const char *lastname);
  ~Student();
  void print(const int printssn = 0);
  void addclass(const char *c);
};



//****************************
//**** student.cc   **********
//****************************



// Student class constructor
Student::Student(const int s, const char *fn, const char *ln) : Personnel(s,fn,ln)
{
  nclasses=0;
}

// Student class destructor
Student::~Student()
{
  for (int i=0; i<nclasses; ++i) delete classes[i];
}

// Add a class to a student file
void Student::addclass(const char *c)
{
  classes[nclasses] = new char[strlen(c)+1];
  strcpy(classes[nclasses], c);
  nclasses += 1;
};

// Print a student file
void Student::print(const int printssn)
{
  Personnel::print(printssn);
  if (nclasses == 0)
    cout << "-- Not Enrolled" << endl;
  else {
    cout << "-- Enrolled:" << endl;
    for (int i=0; i < nclasses; ++i) cout << classes[i];
    cout << endl;
  }
}



// ***********************
// ****   teacher.h   ****
// ***********************

class Teacher : public Personnel {
  int salary;
public:
  Teacher(const int ssn, const char *firstname,
          const char *lastname, const int salary);
  void print(const int printssn = 0);
  void updatesalary(const int sal);
};



//**************************
//****  teacher.cc   *******
//**************************


// Teacher constructor
Teacher::Teacher(const int s, const char *fn, const char* ln,
                 const int sal) : Personnel(s,fn,ln)
{
  salary = sal;
}

// Print a teacher file
void Teacher::print(const int printssn)
{
  Personnel::print(printssn);
  cout << "-- Salary: " << salary << endl;
}

void Teacher::updatesalary(const int sal)
{
  salary = sal;
}


// ***********************
// ****  database.h   ****
// ***********************

class Database {
  Personnel *file;
  Database  *next;
public:
  Database();
  void print();
  void add(Personnel *pf);
  Personnel *locate(const int ssn);
  void remove(const int ssn);
};


//************************
//****  database.cc   ****
//************************


//  Constructor
Database::Database()
{
  file=NULL;
  next=NULL;
}

// Print the database
void Database::print()
{
  Database *tmp=this;

  while (tmp->next != NULL) {
    tmp->file->print();
    tmp = tmp->next;
  }
}

//  Add a file to the database
void Database::add(Personnel *f)
{
  Database *tmp=this;

  while (tmp->next != NULL) {
    tmp = tmp->next;
  }
  tmp->file = f;
  tmp->next = new Database;
}

// Remove a file from the database
void Database::remove(const int s)
{
  Database *tmp=this;

  while (tmp->next != NULL) {
    if (tmp->file->getssn() == s) {
      tmp->file = tmp->next->file;
      tmp->next = tmp->next->next;
      return;
    }
    tmp = tmp->next;
  }
  cout << "Database::remove: file not found" << endl;
}

// Find a file in the database
Personnel *Database::locate(const int s)
{
  Database *tmp=this;
  while (tmp->next != NULL) {
    if (tmp->file->getssn() == s) {
      return tmp->file;
    }
    tmp = tmp->next;
  }
  cout << "Database::locate: file not found" << endl;
  return NULL;
}



// ******************************
// ****  database_test.cc  ******
// ******************************


main()
{
  Database cs;
  Personnel *person;
  int i;

  // Add a student file
	cs.add(new Student(1, "PAUL", "JONES"));

  // Add a teacher file
	cs.add(new Teacher(2, "JOHN", "WHITE", 1000));

 // Locate item in the database with ssn = 1
      person = cs.locate(1);
  
 // Add a physics class
      ((Student*)person)->addclass("PHYSICS");

 // Locate item in the database with ssn = 2
      person = cs.locate(2);

 // Update the salary
      ((Teacher*)person)->updatesalary(2000);

 // Print the database
      cs.print();

 // Delete each data file from database
      for (i=0; i < Personnel::get_num_files(); i++ ) {
        cs.remove(i+1);
      }
}
