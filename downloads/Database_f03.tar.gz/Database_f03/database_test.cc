// Database benchmark program
// Robert Henderson and Benjamin Zorn
// A Comparison of Object-oriented Programming in Four Modern Languages
// Software - Practice and Experience, vol. 24, no. 11, p. 1077 (1994).
// Simplified by Charles Norton and Viktor Decyk

// ******************************
// ****  database_test.cc  ******
// ******************************

#include "personnel.h"
#include "teacher.h"
#include "student.h"
#include "database.h"

main()
{
  Database cs;
  Personnel *person;
  int i;

  // Add a student file
	cs.add(new Student(1, "PAUL", "JONES"));

  // Add a teacher file
	cs.add(new Teacher(2, "JOHN", "WHITE", 1000));

 // Locate item in the database with ssn = 1
      person = cs.locate(1);
  
 // Add a physics class
      ((Student*)person)->addclass("PHYSICS");

 // Locate item in the database with ssn = 2
      person = cs.locate(2);

 // Update the salary
      ((Teacher*)person)->updatesalary(2000);

 // Print the database
      cs.print();

 // Delete each data file from database
      for (i=0; i < Personnel::get_num_files(); i++ ) {
        cs.remove(i+1);
      }
}
